package koschei.models;

public class Deth8 {
}
