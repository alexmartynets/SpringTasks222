package koschei.models;

import org.springframework.stereotype.Component;

@Component
public class Duck5 {

    @Override
    public String toString() {
        return ", в утке яйцо " + "";
    }
}
